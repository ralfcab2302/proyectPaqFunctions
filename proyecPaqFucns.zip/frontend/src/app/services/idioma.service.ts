import { Injectable, signal, inject, ChangeDetectorRef, ApplicationRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
  providedIn: 'root'
})
export class IdiomaService {
  private readonly COOKIE_NAME = 'paqtracer_idioma';
  private readonly DEFAULT_IDIOMA = 'es';
  private appRef = inject(ApplicationRef);
  
  public idiomaActual = signal(this.DEFAULT_IDIOMA);

  constructor(private translate: TranslateService) {
    console.log('🚀 IdiomaService constructor');
    this.translate.setDefaultLang(this.DEFAULT_IDIOMA);
    
    const idiomaGuardado = this.getIdiomaFromCookie() || localStorage.getItem('idioma') || this.DEFAULT_IDIOMA;
    console.log('📋 Idioma inicial:', idiomaGuardado);
    
    this.idiomaActual.set(idiomaGuardado);
    this.translate.use(idiomaGuardado);
  }

  cambiarIdioma(idioma: string) {
    console.log('🔄 ===== CAMBIO DE IDIOMA =====');
    console.log('🔄 De:', this.idiomaActual(), 'a:', idioma);
    
    if (idioma !== this.idiomaActual()) {
      // 1. Actualizar signal
      this.idiomaActual.set(idioma);
      console.log('✅ Signal actualizado');
      
      // 2. Cambiar idioma en TranslateService
      this.translate.use(idioma).subscribe(() => {
        console.log('✅ TranslateService actualizado');
        
        // 3. MÚLTIPLES ESTRATEGIAS para forzar actualización
        
        // Estrategia 1: ApplicationRef.tick()
        this.appRef.tick();
        console.log('✅ Tick 1 ejecutado');
        
        // Estrategia 2: Segundo tick con delay
        setTimeout(() => {
          this.appRef.tick();
          console.log('✅ Tick 2 ejecutado');
        }, 0);
        
        // Estrategia 3: Tercer tick con más delay
        setTimeout(() => {
          this.appRef.tick();
          console.log('✅ Tick 3 ejecutado');
        }, 100);
        
        // Estrategia 4: Forzar re-renderizado completo
        setTimeout(() => {
          // Cambiar y volver a cambiar para forzar actualización
          const temp = this.idiomaActual();
          this.idiomaActual.set('');
          this.idiomaActual.set(temp);
          console.log('✅ Re-renderizado forzado');
        }, 150);
      });
      
      // 4. Guardar preferencias
      localStorage.setItem('idioma', idioma);
      this.setIdiomaCookie(idioma);
      console.log('✅ Preferencias guardadas');
      
      console.log('✅ ===== FIN CAMBIO DE IDIOMA =====');
    }
  }

  inicializarIdioma() {
    console.log('🔄 Inicializando idioma...');
    const idioma = this.getIdiomaFromCookie() || localStorage.getItem('idioma') || this.DEFAULT_IDIOMA;
    this.idiomaActual.set(idioma);
    this.translate.use(idioma);
    console.log('✅ Idioma inicializado:', idioma);
  }

  private getIdiomaFromCookie(): string | null {
    const cookies = document.cookie.split(';');
    for (const cookie of cookies) {
      const [name, value] = cookie.trim().split('=');
      if (name === this.COOKIE_NAME) {
        return decodeURIComponent(value);
      }
    }
    return null;
  }

  private setIdiomaCookie(idioma: string) {
    const expires = new Date();
    expires.setFullYear(expires.getFullYear() + 1);
    document.cookie = `${this.COOKIE_NAME}=${encodeURIComponent(idioma)}; expires=${expires.toUTCString()}; path=/; SameSite=Lax`;
  }
}