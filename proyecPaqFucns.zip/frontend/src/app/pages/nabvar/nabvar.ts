import { Component, inject, OnInit, signal } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { AuthService } from '../../services/auth';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-nabvar',
  imports: [TranslateModule],
  templateUrl: './nabvar.html',
  styleUrl: './nabvar.css',
})
export class Nabvar implements OnInit {
  protected rolUser = localStorage.getItem('usuario')
    ? JSON.parse(localStorage.getItem('usuario')!).rol
    : null;
  protected correoUser = localStorage.getItem('usuario')
    ? JSON.parse(localStorage.getItem('usuario')!).correo
    : null;
  private authService = inject(AuthService);
  private translate = inject(TranslateService);
  protected router    = inject(Router);
  protected rutaActual  = signal('');
  protected menuAbierto = signal(false);
  protected idiomaActual = signal('es');

  ngOnInit(): void {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.rutaActual.set(event.url);
        this.menuAbierto.set(false);
      }
    });
    this.rutaActual.set(this.router.url);
  }

  cerrarSesion() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  protected cambiarIdioma() {
    console.log('🔘 Navbar cambiarIdioma - idioma actual:', this.idiomaActual());
    
    const nuevo = this.idiomaActual() === 'es' ? 'en' : 'es';
    console.log('🔘 Nuevo idioma calculado:', nuevo);
    
    this.idiomaActual.set(nuevo);
    this.translate.use(nuevo);
    localStorage.setItem('idioma', nuevo);
    
    console.log('🔘 Navbar cambiarIdioma - llamada completada');
  }

  esSuperadmin() { return this.rolUser === 'superadmin'; }
  esAdmin() { return this.rolUser === 'superadmin' || this.rolUser === 'admin'; }
  estaEn(ruta: string) { return this.rutaActual() === ruta; }
}